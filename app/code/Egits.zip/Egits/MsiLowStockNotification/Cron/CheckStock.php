<?php

namespace Egits\MsiLowStockNotification\Cron;

use Egits\MsiLowStockNotification\Model\StockManagement;
use Magento\Framework\Exception\LocalizedException;

class CheckStock
{
    /**
     * @var StockManagement
     */
    protected $stockManagement;

    /**
     * LowStockCheck constructor.
     * @param StockManagement $stockManagement
     */
    public function __construct(
        StockManagement $stockManagement
    ) {
        $this->stockManagement = $stockManagement;
    }

    /**
     * Execute the cron job
     * @return $this
     */
    public function execute()
    {
        try {
            $configData = $this->stockManagement->getModuleConfig();
            $isEnabled = (int) ($configData['general']['enable'] ?? 0);

            if ($isEnabled) {
                $wishlistData = $this->stockManagement->getWishlistCollection();
                $lowStockSources = $this->stockManagement->checkSources($wishlistData);
                $this->stockManagement->saveLowStockItemData($lowStockSources);
            } else {
                // Log a message or send an email notification that the module is not enabled
            }
        } catch (LocalizedException $e) {
            // Log or handle any exceptions
        }

        return $this;
    }
}
